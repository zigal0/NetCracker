package jdbcexamples;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author logunov
 */
public class JdbcExamples {

    private static final String CONNECTION_STRING = "jdbc:oracle:thin:@localhost:1521/orcl";
    private static final String USERNAME = "HR";
    private static final String PASSWORD = "HR";
    private static final int COUNT = 10_000;

    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        noBindVariables();
        useBindVariables();
    }

    private static void noBindVariables() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.OracleDriver"); // register driver
        
        try (Connection con = DriverManager.getConnection(CONNECTION_STRING, USERNAME, PASSWORD);
                Statement stat = con.createStatement()) {
            long startTime = System.currentTimeMillis();
            for (int i = 0; i < COUNT; i++) {
                try (ResultSet rs = stat.executeQuery("select " + i + " from dual")) {
                    while (rs.next()) {
                        rs.getString(1);
                    }
                }
            }
            long endTime = System.currentTimeMillis();
            System.out.println(COUNT + " distinct queries took " + (endTime - startTime) + "ms");
        }
    }

    private static void useBindVariables() throws ClassNotFoundException, SQLException {
        Class.forName("oracle.jdbc.OracleDriver"); // register driver
        
        try (Connection con = DriverManager.getConnection(CONNECTION_STRING, USERNAME, PASSWORD);
                PreparedStatement ps = con.prepareStatement("select ? from dual")) {
            long startTime = System.currentTimeMillis();
            for (int i = 0; i < COUNT; i++) {
                ps.setInt(1, i);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        rs.getString(1);
                    }
                }
            }
            long endTime = System.currentTimeMillis();
            System.out.println("1 query with " + COUNT + " distinct bind variables took " + (endTime - startTime) + "ms");
        }
    }
}
